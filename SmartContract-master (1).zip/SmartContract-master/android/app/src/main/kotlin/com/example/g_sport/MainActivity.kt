package com.example.g_sport

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
