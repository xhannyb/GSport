import 'package:flutter/cupertino.dart';

class AppColors {
  static const primaryColor = Color(0xFF293241);
  static const textColor = Color(0xFF293241);
}