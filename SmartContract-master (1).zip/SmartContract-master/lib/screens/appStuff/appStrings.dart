class AppStrings {
  static const String athlete = 'Athletes';
  static const String fan = 'Fans';
  static const String info = 'Athlete Infomation';
}